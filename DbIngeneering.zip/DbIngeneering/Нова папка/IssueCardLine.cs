﻿using System;
using System.Collections.Generic;

namespace AAEICS.Database.Models;

public partial class IssueCardLine
{
    public int CardLineId { get; set; }

    public int CardId { get; set; }

    public DateTime LineDate { get; set; }

    public int Reason { get; set; }

    public int ReferenceDocument { get; set; }

    public int Donor { get; set; }

    public int Category { get; set; }

    public int Recipient { get; set; }

    public string? CarBrand { get; set; }

    public string? CarNumber { get; set; }

    public string? CargoRecipientData { get; set; }

    public virtual RecordCard Card { get; set; } = null!;

    public virtual Category CategoryNavigation { get; set; } = null!;

    public virtual ICollection<DocumentIssueCardLine> DocumentIssueCardLines { get; set; } = new List<DocumentIssueCardLine>();

    public virtual TransferInstance DonorNavigation { get; set; } = null!;

    public virtual Reason ReasonNavigation { get; set; } = null!;

    public virtual TransferInstance RecipientNavigation { get; set; } = null!;
}
